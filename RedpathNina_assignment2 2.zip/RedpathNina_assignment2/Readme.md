Readme: 
    to complete this assignment I used several online resources. I did not collaborate with any other students. I have listed the online resources next to the concepts that I used them to learn. 


Sources: 
concatenating arrays: 
https://stackoverflow.com/questions/5080028/what-is-the-most-efficient-way-to-concatenate-n-arrays

iterating through election result object: 
https://stackoverflow.com/questions/16626735/how-to-loop-through-an-array-containing-objects-and-access-their-properties?rq=1

used to sum specific variables of an array of objects: 
https://gist.github.com/benwells/0111163b3cccfad0804d994c70de7aa1 

for help with the tooltip: 
https://www.npmjs.com/package/d3-tip
