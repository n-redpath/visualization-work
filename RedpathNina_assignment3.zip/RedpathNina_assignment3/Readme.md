Overview of the parts of code that I am handing in: 
        This is a web page that shows 6 different graphs, each relating to one of 6 fairy tales from the english.txt dataset. 
        Some of the code structure is taken from assignment 2 (such as having each button call a new graph)
        Some of the code structure is taken from studios 3-7 (such as creating axes for graphs)
        The sentiment analysis for each story is my own, although the json file of words relating to scores, and the array containing negating words are taken from sentiment.js. 
        Other than that, I had no collaborators and will cite specific sources in the code, where applicable. 

The interface should be intuitive; click on each icon associated with a title of a fairytale to see the graph of sentiment over time for that story. Click between them to see the graph animate and change. 
